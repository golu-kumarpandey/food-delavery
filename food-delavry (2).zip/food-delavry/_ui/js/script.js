// hambburger menu logic

const menuIcon = document.getElementById("menuIcon");
const mobileNav = document.getElementById("mobileNav");
const wrapper = document.getElementById("wrapper");

menuIcon.addEventListener("click", (e) => {
  e.stopPropagation();
  mobileNav.classList.toggle("active");
});

mobileNav.addEventListener("click", (e) => {
  e.stopPropagation();
  mobileNav.classList.toggle("active");
});

wrapper.addEventListener("click", (e) => {
  if (!mobileNav.contains(e.target) && mobileNav.classList.contains("active")) {
    mobileNav.classList.remove("active");
  }
});

// form validation logic

const inputGroup = document.querySelectorAll(".input-group");

inputGroup.forEach((eachInput) => {
  const currentInput = eachInput.querySelector("input");
  const currentErrorMsg = eachInput.querySelector(".error-msg");

  currentInput.addEventListener("blur", () => {
    const inputId = currentInput.getAttribute("id");
    const inputValue = currentInput.value.trim();

    if (inputValue === "") {
      currentErrorMsg.innerHTML = `${inputId} requred*`;
    } else {
      validationInput(inputId, inputValue, currentErrorMsg);
      currentErrorMsg.innerHTML = "";
    }
  });
});

function validationInput(fieldName, value, errmsg) {
  if (fieldName === "name") {
    if (!/^[a-zA-Z ]+$/.test(value)) {
      errmsg.textContent = "Please enter a valid name (letters only).";
    } else {
      errmsg.textContent = "";
    }
  }

  if (fieldName === "email") {
    if (!/^\S+@\S+\.\S+$/.test(value)) {
      errmsg.textContent = "Please enter a valid email address.";
    } else {
      errmsg.textContent = "";
    }
  }
}

// from validation on button click logic
const submitButton = document.querySelector(".reservation-section button");
const formSubbmission = document.querySelector(".from-submission");
const conformButton = document.getElementById("conformButton");
const cancelButton = document.getElementById("cancelButton");
const loader = document.querySelector(".loader");

submitButton.addEventListener("click", (e) => {
  e.preventDefault();
  let checkEmptyInput = false;

  inputGroup.forEach((eachInput) => {
    const currentInput = eachInput.querySelector("input");
    const currentErrorMsg = eachInput.querySelector(".error-msg");
    const inputId = currentInput.getAttribute("id");

    if (currentInput.value === "") {
      currentErrorMsg.innerHTML = `${inputId} required*`;
      checkEmptyInput = true;
    } else {
      currentErrorMsg.innerHTML = "";
    }
  });
  if (!checkEmptyInput) {
    formSubbmission.classList.add("active");
  }
});

conformButton.addEventListener("click", () => {
  inputGroup.forEach((eachInput) => {
    const currentInput = eachInput.querySelector("input");
    const currentErrorMsg = eachInput.querySelector(".error-msg");
    currentInput.value = "";
    currentErrorMsg.innerHTML = "";
  });
  formSubbmission.classList.remove("active");
});

cancelButton.addEventListener("click", () => {
  formSubbmission.classList.remove("active");
});

function createStars() {
  const container = document.querySelector(".from-submission");
  for (let i = 0; i < 200; i++) {
    const star = document.createElement("div");
    star.className = "star";
    star.style.left = Math.random() * 100 + "%";
    star.style.top = Math.random() * 100 + "%";
    const sizes = ["1px", "1.5px", "2px", "2.5px"];
    star.style.width = sizes[Math.floor(Math.random() * sizes.length)];
    star.style.height = star.style.width;
    star.style.animationDelay = Math.random() * 2 + "s";
    container.appendChild(star);
  }
}

function createMeteors() {
  setInterval(() => {
    const meteor = document.createElement("div");
    meteor.className = "meteor";
    meteor.style.top = Math.random() * 100 + "%";
    meteor.style.left = Math.random() * 100 + "%";
    meteor.style.animationDuration = 1 + Math.random() * 2 + "s";
    document.querySelector(".from-submission").appendChild(meteor);
    setTimeout(() => meteor.remove(), 2000);
  }, 3000);
}

createStars();
createMeteors();

// login function logic
const user = {
  userName: "golu",
  password: "golu@1122",
};

const inputUserName = document.getElementById("loginUser");
const inputUserPassword = document.getElementById("loginPassword");
const loginBtn = document.getElementById("loginBtn");
const userError = document.querySelector(".user_error");
const passwordError = document.querySelector(".password_error");
const app = document.querySelector(".app");
const login = document.querySelector(".login");
const { userName, password } = user;

inputUserName.addEventListener("blur", () => {
  const inputUserNameValue = inputUserName.value.trim();
  if (inputUserNameValue === "") {
    userError.innerHTML = "Required*";
  } else {
    userError.innerHTML = "";
  }
});

inputUserPassword.addEventListener("blur", () => {
  const inputUserPasswordValue = inputUserPassword.value.trim();
  if (inputUserPasswordValue === "") {
    passwordError.innerHTML = "Required*";
  } else {
    passwordError.innerHTML = "";
  }
});

loginBtn.addEventListener("click", (e) => {
  e.preventDefault();

  const inputUserNameValue = inputUserName.value.trim();
  const inputUserPasswordValue = inputUserPassword.value.trim();

  console.log(inputUserNameValue);
  console.log(inputUserPasswordValue);

  if (inputUserNameValue === "") {
    userError.innerHTML = "Required*";
  } else {
    if (inputUserNameValue === userName) {
      userError.innerHTML = "";
    } else {
      userError.innerHTML = "Invalid User";
    }
  }

  if (inputUserPasswordValue === "") {
    passwordError.innerHTML = "Required*";
  } else {
    if (inputUserPasswordValue === password) {
      passwordError.innerHTML = "";
    } else {
      passwordError.innerHTML = "Invalid Password";
    }
  }

  if (inputUserPasswordValue === password && inputUserNameValue === userName) {
    login.style.display = "none";
    loader.classList.add("active");
    setTimeout(() => {
      loader.classList.remove("active");
      app.style.display = "block";
      inputUserPassword.value = "";
    }, 1000);
  }
});

// logic for order popup
const orderPopupSection = document.querySelector(".order-popup-section");
const orderButton = document.querySelectorAll(".burger-content a");
const container = document.querySelector(".order-popup-content");
const closebutton = document.querySelector(".close-btn");
const orderNow = document.querySelectorAll(".order-popup-slider .footer");

// Show popup on burger button click
orderButton.forEach((eachButton) => {
  eachButton.addEventListener("click", () => {
    orderPopupSection.classList.toggle("active");
  });
});

// Close popup on background click
orderPopupSection.addEventListener("click", (e) => {
  if (e.target === orderPopupSection) {
    orderPopupSection.classList.toggle("active");
  }
});

// Close popup on close button
closebutton.addEventListener("click", () => {
  orderPopupSection.classList.toggle("active");
});

// Order now buttons
orderNow.forEach((order) => {
  order.addEventListener("click", () => {
    orderPopupSection.classList.toggle("active");
  });
});

// scrollbar navigation heightlight logic

window.addEventListener("scroll", () => {
  const sections = document.querySelectorAll("section");
  const navLinks = document.querySelectorAll(".nav-link");
  let currentId = "";

  // Sabhi sections me loop chalao, aur currentId update karo
  sections.forEach((eachSection) => {
    const sectionTop = eachSection.offsetTop;
    const sectionHeight = eachSection.offsetHeight;

    if (pageYOffset >= sectionTop - sectionHeight / 3) {
      if (eachSection.id) {
        currentId = eachSection.id;
      }

      // console.log("inner current id ", currentId);
    }
  });

  // console.log("ourterCurrent id", currentId);

  // Ab sabhi navLinks me loop chalao aur active class lagao ya hatao
  navLinks.forEach((link) => {
    link.classList.remove("active");
    if (link.getAttribute("href") === "#" + currentId) {
      link.classList.add("active");
    }
  });
});

// iframe modal logic

function openModal(videoUrl) {
  const modal = document.getElementById("videoModal");
  const iframe = document.getElementById("videoIframe");
  iframe.src = videoUrl;
  modal.style.display = "flex";
}

function closeModal() {
  const modal = document.getElementById("videoModal");
  const iframe = document.getElementById("videoIframe");
  iframe.src = ""; // Stop video
  modal.style.display = "none";
}

// fade up affact

window.addEventListener("scroll", function () {
  document.querySelectorAll(".scroll-effect").forEach(function (section) {
    const top = section.getBoundingClientRect().top;
    const winddowHeight = window.innerHeight;
    if (top < winddowHeight - 200) {
      section.classList.add("visible");
    } else {
      section.classList.remove("visible");
    }
  });
});

// chat bot control here

const interval = setInterval(() => {
  const dfMessenger = document.querySelector("df-messenger");

  if (dfMessenger && dfMessenger.shadowRoot) {
    const innerChat = dfMessenger.shadowRoot.querySelector("df-messenger-chat");

    if (innerChat && innerChat.shadowRoot) {
      const chatWrapper = innerChat.shadowRoot.querySelector(".chat-wrapper");

      if (chatWrapper) {
        chatWrapper.style.height = "400px";

        clearInterval(interval);
      } else {
        console.log(
          "⏳ Still waiting for chat-wrapper inside df-messenger-chat..."
        );
      }
    } else {
      console.log("⏳ Waiting for df-messenger-chat shadowRoot...");
    }
  } else {
    console.log("⏳ Waiting for df-messenger and its shadowRoot...");
  }
}, 300);
